#' @title rbfmvar: Residual-Based Fully Modified Vector Autoregression
#'
#' @description
#' Implements the Residual-Based Fully Modified Vector Autoregression
#' (RBFM-VAR) estimator following Chang (2000). The RBFM-VAR procedure
#' extends Phillips (1995) FM-VAR to handle any unknown mixture of I(0),
#' I(1), and I(2) components without prior knowledge of the number or
#' location of unit roots.
#'
#' @section Main Functions:
#' \describe{
#'   \item{\code{\link{rbfmvar}}}{Estimate an RBFM-VAR model.}
#'   \item{\code{\link{granger_test}}}{Test for Granger non-causality.}
#'   \item{\code{\link{irf}}}{Compute impulse response functions.}
#'   \item{\code{\link{fevd}}}{Compute forecast error variance decomposition.}
#'   \item{\code{\link{forecast.rbfmvar}}}{Generate out-of-sample forecasts.}
#' }
#'
#' @section Key Features:
#' \itemize{
#'   \item Handles unknown mixtures of I(0), I(1), and I(2) variables
#'   \item Automatic lag selection via AIC, BIC, or HQ
#'   \item Multiple kernels for LRV estimation (Bartlett, Parzen, QS)
#'   \item Andrews (1991) automatic bandwidth selection
#'   \item Granger non-causality testing with asymptotic chi-squared inference
#'   \item Impulse response functions with bootstrap confidence intervals
#'   \item Forecast error variance decomposition
#'   \item Out-of-sample forecasting
#' }
#'
#' @section Methodology:
#' The RBFM-VAR model is based on Chang (2000), which develops a fully
#' modified VAR estimation procedure that is robust to unknown integration
#' orders. The key innovation is using second differences to eliminate
#' I(2) trends while applying FM corrections to handle endogeneity from
#' I(1) regressors.
#'
#' The estimator achieves:
#' \itemize{
#'   \item Zero mean mixed normal limiting distribution
#'   \item Chi-square Wald statistics for hypothesis testing
#'   \item Consistent estimation regardless of integration orders
#' }
#'
#' @references
#' Chang, Y. (2000). Vector Autoregressions with Unknown Mixtures of I(0), I(1),
#' and I(2) Components. \emph{Econometric Theory}, 16(6), 905-926.
#' \doi{10.1017/S0266466600166071}
#'
#' Phillips, P. C. B. (1995). Fully Modified Least Squares and Vector
#' Autoregression. \emph{Econometrica}, 63(5), 1023-1078.
#' \doi{10.2307/2171721}
#'
#' Andrews, D. W. K. (1991). Heteroskedasticity and Autocorrelation Consistent
#' Covariance Matrix Estimation. \emph{Econometrica}, 59(3), 817-858.
#' \doi{10.2307/2938229}
#'
#' @docType package
#' @name rbfmvar-package
#' @aliases rbfmvar-package
#'
#' @importFrom stats coef fitted residuals vcov pnorm qnorm pchisq quantile
#'   var cov cor rnorm
#' @importFrom MASS ginv
#' @importFrom graphics par plot abline polygon barplot legend
#' @importFrom grDevices rainbow rgb
"_PACKAGE"
